/**
 * Creates Duck Enemies to spawn
 */
public class Duck
{
    float health;
    int xPos;
    int yPos;
    Texture img;
    float damageOutput;


    /**
     * Initiates Duck
     * 
     * @param x X position of Duck
     * @param y Y position of Duck
     */
    public void Create(int x, int y)
    {
        this.health = 100.0;
        damageOutput = 10.0;
        img = new Texture("duck.png");
        this.xPos = 0;
        this.yPos = 0;
    }

    /**
     * Decreases health on Duck
     * 
     * @param damage amount of damage to deduct from health
     */
    public int takeDamage(int damage)
    {
        this.health -= damage;
        if(this.health<=0)
        {
            this.die();
        }
    }

    /**
     * Sets position of duck to null (death)
     */
    public void die()
    {
        this.xPos = null;
        this.yPos = null;
    }

    /**
     * Allows duck to move
     */
    public int move()
    {
        //This method needs to be able to read the tile map file to decide where to move
        //i need another method to call this one every second or render time, this method will also rewrite the file to show where it has already passed.
    }
}


/**
 * Extends Duck class for different variations
 */
public class BlueDuck extends Duck
{
    /**
     * Initiates Duck
     * 
     * @param x X position of Duck
     * @param y Y position of Duck
     */
    @Override
    public void Create()
    {
        this.health = 150.0;
        damageOutput = 15.0;
        img = new Texture("duck.png"); // Need to make different Color Ducks
        this.xPos = 0;
        this.yPos = 0;
    }
}
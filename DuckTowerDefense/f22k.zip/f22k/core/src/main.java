
public class main {
    public static void main(){
        System.out.println("Hello");
    }
}

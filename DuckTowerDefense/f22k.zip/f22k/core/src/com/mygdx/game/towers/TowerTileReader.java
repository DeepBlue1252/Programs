package com.mygdx.game.towers;

public class TowerTileReader {
	

	public int calculateTowerCordX(float x) {
		int ret = (int) x;
		
		ret /= 64;
		ret *= 64;
		
		return ret;
	}
	
	public int calculateTowerCordY(float y) {
		int ret = (int) y;
		
		ret /= 64;
		ret *= 64;
		
		return ret;
	}
}



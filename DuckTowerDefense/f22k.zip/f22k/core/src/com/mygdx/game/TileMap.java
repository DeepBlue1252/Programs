package com.mygdx.game;

import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

import java.util.ArrayList;



/**
 * The tilemap class stores the level as an array of Tiles.
 */
public class TileMap {
    public ArrayList<Tile> tileArray;
    Stage levelStage;

    Pos startPos;
    Pos endPos;

    /**
     * This class stores the tiles that make up a level. There is no behaviour besides initializing.
     * @param fileName name of the text file containing the level's information.
     */
    public TileMap(String fileName, Stage levelStage){
        tileArray = new ArrayList<Tile>();
        this.levelStage = levelStage;
            try{
                tileArray = TextMapConverter.convertToTiles(fileName);}
            catch(Exception e){
                e.printStackTrace();
            }
            addTilesToStage();
        }

    public void draw(){
        for(int i = 0; i < tileArray.size(); i++){
            levelStage.getBatch().draw(tileArray.get(i).displayTexture, tileArray.get(i).xPos, tileArray.get(i).yPos);
        }
    }

    public void addTilesToStage(){
        for(int i = 0; i < tileArray.size(); i++){

        }
    }
}

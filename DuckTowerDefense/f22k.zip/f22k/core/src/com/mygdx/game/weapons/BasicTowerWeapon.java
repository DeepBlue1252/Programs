package com.mygdx.game.weapons;

import com.mygdx.game.towers.BasicTower;

public class BasicTowerWeapon extends TowerWeapon {
	
	public BasicTowerWeapon(BasicTower tower) { 
		super.equipedTower = tower;	
	}

	@Override
	void Damage(DuckStub duck) {	//takes the attack from the tower object and applies it to the Passed in Duck object as damage.
									//if the amount of damage would kill the duck then it will delete the duck object.
		duck.hurt(equipedTower.getAttack());
		if (duck.getHealth() <= 0) { //kills the duck
			duck = null;  
		}
	}
}

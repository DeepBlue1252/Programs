package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.screens.Level1TestScreen;
import com.mygdx.game.screens.MainMenuScreen;

public class EscapeButton extends EasyButton {

    public EscapeButton(Stage stage, Game game){
         super("Escape", 5,850, stage, game);
         button.removeListener(button.getClickListener());

         button.addListener(new ScreenSwitchInputListener(game){
             @Override
             public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                    //Logic when button is unreleased.

             }
             public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                 //Logic when button is pressed
                 game.setScreen(new MainMenuScreen(game));
                 return true;
             }
         });


        }
    }


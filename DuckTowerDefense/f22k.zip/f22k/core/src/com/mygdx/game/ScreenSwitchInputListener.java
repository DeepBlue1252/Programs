package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.InputListener;

public class ScreenSwitchInputListener extends InputListener {

    public Game game;

    public ScreenSwitchInputListener(Game game){
        super();
        this.game = game;
    }
}

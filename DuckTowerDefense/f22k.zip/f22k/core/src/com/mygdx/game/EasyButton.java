package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;


public class EasyButton{
    private Skin buttonSkin;
    private Game game;
    public String text;
    public TextButton button;

    public EasyButton(String buttonText, int x_pos, int y_pos, Stage stage, Game game){
        buttonSkin = new Skin(Gdx.files.internal("skin/clean-crispy-ui.json"));
        text = buttonText;
        button = new TextButton(buttonText, buttonSkin);
        this.game = game;

        button.setPosition(x_pos,y_pos);
        button.setSize(128,128);
        stage.addActor(button);
        button.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.

            }
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is pressed.

                return true;
            }

        });
    }


}

package com.mygdx.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.mygdx.game.EasyButton;
import com.mygdx.game.ScreenSwitchInputListener;
import com.mygdx.game.screens.OptionsMenu;
import com.mygdx.game.options.Volume;
public class VolumeDown extends EasyButton {

    Volume currentVolume = new Volume(100);
    VolumeDown(Stage stage, Game game) {

        super("Volume Down", 656, 200, stage, game);
        button.removeListener(button.getClickListener());
        button.addListener(new ScreenSwitchInputListener(game) {
            @Override
            public void touchUp(InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.

            }

            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is pressed
                currentVolume.turnDown();

                return true;
            }
        });
    }
}
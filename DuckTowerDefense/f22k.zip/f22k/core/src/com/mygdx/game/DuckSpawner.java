package com.mygdx.game;
import com.badlogic.gdx.graphics.Texture;
import java.util.LinkedList;

public class DuckSpawner {
    private int amount;
    private double seconds;
    private double spawnTimer;
    Texture img;
    private LinkedList<Duck> ducks;
    private Duck prototype;

    public DuckSpawner(LinkedList<Duck> ducks, int amount, double seconds, Duck prototype){
        this.ducks = ducks;
        this.amount = amount;
        this.seconds = seconds;
        spawnTimer = seconds;
        this.prototype = prototype;
    }

    public void spawn(double deltaTime){
        if(amount < 1){
            return;
        }
        spawnTimer -= deltaTime;
        if(spawnTimer<=0){
            amount-=1;
            spawnTimer = seconds;
            ducks.add(prototype.clone());
        }
    }

}
package com.mygdx.game;

import com.mygdx.game.towers.BasicTowerButton;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.screens.MainMenuScreen;

public class GameGUI extends BasicGUI{
    public GameGUI(Stage myStage, Game myGame){
        super(myStage, myGame);
    }

    private Stage stage;
    private Game game;
    private EscapeButton button;
    private MenuButton menubutton;


    @Override
    public void addButtons(){

       BasicTowerButton button1 =  new BasicTowerButton("BasicTower", 0, 0, myStage, myGame);
       BasicTowerButton button2 =  new BasicTowerButton("Tower2", 127, 0, myStage, myGame);
       button = new EscapeButton(myStage, myGame);
       menubutton = new MenuButton(myStage,myGame);
    }



}




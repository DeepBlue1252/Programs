package com.mygdx.game.towers;	

import com.badlogic.gdx.graphics.Texture;

//tower is used as a factory class for other [Type]Tower (i.e. BasicTower) object 
public abstract class Tower {
	protected int size;		//size in tile by tile e.i. 1x1 
	protected int cost;
	protected int attack;	//attack damage
	protected int aSpeed;	//attack speed in attacks per second
	protected int range;	//range in tiles
	protected int locationRow;	//row the tower is located on
	protected int locationCol;	//column the tower is located on.
	protected Texture texture;
	
	
	//getter methods
	public abstract int getAttack();
	public abstract Texture getTexture();
	public abstract int getCost();
	
}

package com.mygdx.game.weapons;

public class DuckStub {
	
	private int health;
	
	public DuckStub(int health) {
		this.health = health;
	}
	
	public void hurt(int damage) {
		this.health -= damage;
	}
	
	public int getHealth() {
		return this.health;
	}

}

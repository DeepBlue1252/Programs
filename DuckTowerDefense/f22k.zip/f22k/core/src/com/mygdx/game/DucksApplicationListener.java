package com.mygdx.game;

import java.util.LinkedList;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class DucksApplicationListener extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	Duck duck;
	private LinkedList<Duck> ducks;
	public DuckSpawner duckSpawn;
	private int SpawnX;
	private int SpawnY;
	//public char[] directions = {'D','D','R','D','R','R','U','R','U','R'};
	public char[] directions = {'D','D','R','D','R','R','U','R','U','R','R','R','R','R','R'};

	@Override
	public void create () {
		batch = new SpriteBatch();
		img = new Texture("duck.png");

		SpawnX = 35;
		SpawnY = 450;
		duck = new Duck(img, SpawnX, SpawnY);
		ducks = new LinkedList<Duck>();
		duckSpawn = new DuckSpawner(ducks, 50, 2f,duck);
	}


	@Override
	public void render () {
		//ScreenUtils.clear(0, 50, 75, 1);
		batch.begin();
		duckSpawn.spawn(Gdx.graphics.getDeltaTime());
		for(Duck duck:ducks){
			duck.move(directions);
			duck.draw(batch);
		}
		batch.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}

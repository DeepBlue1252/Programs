package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;

public class Tile extends com.badlogic.gdx.scenes.scene2d.Actor{
    public Texture displayTexture;
    public int xPos;
    public int yPos;

    public Tile(String textureName, int xPos, int yPos){
        this.displayTexture = new Texture(textureName);
        this.xPos = xPos;
        this.yPos = yPos;
    }
}

package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class RealMenu implements Screen {
    SpriteBatch batch;
    BitmapFont font;
    Texture redEnemyDuck_img,blueEnemyDuck_img,regEnemyDuck_img,lightTower_img,heavyTower_img,
            theImage_img,breadImage_img,menuBread_img;
    public Sprite redEnemyDuck,blueEnemyDuck,regEnemyDuck,lightTower,
            heavyTower,theImage,breadImage,menuBread;
    public EscapeButton escapebutton;
    public returnButton returnbutton;
    private Game game;
    private Stage stage;
    public RealMenu(Game game)
    {this.game = game;
        batch = new SpriteBatch();
        font = new BitmapFont();
        redEnemyDuck_img = new Texture("redEnemyDuck.jpg");
        redEnemyDuck = new Sprite(redEnemyDuck_img);

        blueEnemyDuck_img = new Texture("blueEnemyDuck.jpg");
        blueEnemyDuck = new Sprite(blueEnemyDuck_img);

        regEnemyDuck_img = new Texture("regEnemyDuck.jpg");
        regEnemyDuck = new Sprite(regEnemyDuck_img);

        lightTower_img = new Texture("lightTower.jpg");
        lightTower = new Sprite(lightTower_img);

        heavyTower_img = new Texture("HeavyTower.jpg");
        heavyTower = new Sprite(heavyTower_img);

        theImage_img = new Texture("theImage.jpg");
        theImage = new Sprite(theImage_img);

        breadImage_img = new Texture("breadImage.jpg");
        breadImage = new Sprite(breadImage_img);

        menuBread_img = new Texture("menuBread.jpg");
        menuBread = new Sprite(menuBread_img);
    }

    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        //Gdx.gl.glClearColor(.25f, .25f, .25f, 1);
        escapebutton = new EscapeButton(stage, game);
        returnbutton = new returnButton(stage,game);
    }


    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.gl.glClearColor(255f, 255f, 0f, 1);
        stage.act();
        stage.draw();

        batch.begin();


        redEnemyDuck.draw(batch);
        redEnemyDuck.setPosition(1000,600);

        blueEnemyDuck.draw(batch);
        blueEnemyDuck.setPosition(600,600);

        regEnemyDuck.draw(batch);
        regEnemyDuck.setPosition(200,600);

        lightTower.draw(batch);
        lightTower.setPosition(400,380);

        heavyTower.draw(batch);
        heavyTower.setPosition(800,375);

        theImage.draw(batch);
        theImage.setPosition(100,100);

        breadImage.draw(batch);
        breadImage.setPosition(890,100);

        menuBread.draw(batch);
        menuBread.setPosition(520,50);

        font.setColor(0f,0f,0f,1);
        font.draw(batch,"The objective of this game is to defeat all the ducks before they reach the end of the track", 350, 800);
        font.draw(batch,"We have two types of towers a light tower which has higher range and lower damage and a heavy tower which has lower range but higher damage", 200, 750);
        font.draw(batch,"The different fuck types that we have are...",500,700);

        font.draw(batch,"Regular Duck!",190,590);
        font.draw(batch,"Doesn't deal a lot of damage or have a ton of health",90,570);
        font.draw(batch,"But his Heart is unmatched!",150,550);

        font.draw(batch,"Medium Duck!",590,590);
        font.draw(batch,"Has Decent health and Damage",530,570);
        font.draw(batch,"Don't want him getting through!",537,550);

        font.draw(batch,"Heavy Duck!",995,590);
        font.draw(batch,"Has the highest health and Damage",920,570);
        font.draw(batch,"Might be slow, but packs a punch!",925,550);

        font.draw(batch,"Tower types...",590,510);
        font.draw(batch,"Light Tower!",414,370);
        font.draw(batch,"Has a fast attack speed with lower damage",325,350);
        font.draw(batch,"Great Price for the damage!",370,330);

        font.draw(batch,"Heavy Tower!",810,370);
        font.draw(batch,"Has high damage with a slower attack speed",720,350);
        font.draw(batch,"Might be pricey, but frightens the ducks!",740,330);
        font.draw(batch,"Be aware you must defend...",555,290);
        batch.end();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }


    public void hide() {

    }

    @Override
    public void dispose() {
        batch.dispose();
        font.dispose();
        stage.dispose();
    }

}




package com.mygdx.game;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import static java.lang.Math.floor;

/**
 * Creates Duck Enemies to spawn
 */
public class Duck
    implements Cloneable
{

    SpriteBatch batch;
    double health;
    float xPos;
    float yPos;
    Texture img;
    double damageOutput;
    int DirectionPos;
    float movement;

    /**
     * Initiates Duck
     *
     * @param x X position of Duck
     * @param y Y position of Duck
     */
    public Duck(Texture img, float x, float y)
    {
        this.health = 100.0;
        this.damageOutput = 10.0;
        this.img = img;
        this.xPos = x;
        this.yPos = y;
        this.DirectionPos = 0;
        this.movement = 0;
    }

    /**
     * Decreases health on Duck
     *
     * @param damage amount of damage to deduct from health
     */
    public void takeDamage(int damage)
    {
        this.health -= damage;
        if(this.health<=0)
        {
            this.die();
        }
    }

    public void draw(SpriteBatch batch) {
        batch.draw(img, xPos, yPos);
    }

    /**
     * Die animation, actual death will be taken care of by java garbage collector
     */
    public void die()
    {
        xPos = 10000;
    }

    /**
     * Will read tileMap and will return an int based on the direction it needs to move in
     * @param directions txt file with types of tiles and arrangement laid out
     */
    public char readTileMap(char[] directions)
    {
        double totalMove = movement;
        DirectionPos = (int) (floor(totalMove/100));
        if(DirectionPos> directions.length-1){
            return 'R';
        }
        return directions[DirectionPos];
    }

    /**
     * Allows duck to move
     */
    public void move(char[] directions)
    {
        char Dir = readTileMap(directions);
        if(Dir=='D'){
            yPos-=1;
            movement++;
        } else if(Dir=='U'){
            yPos+=1;
            movement++;
        } else if(Dir=='L') {
            xPos -= 1;
            movement++;
        } else if(Dir=='R'){
            xPos+=1;
            movement++;
        }
        if(xPos>2000){
            this.die();
        }
    }
    @Override
    public Duck clone() {
        try {
            Duck clone = (Duck) super.clone();
            clone.img = img;
            clone.xPos = xPos;
            clone.yPos = yPos;
            clone.health = health;
            clone.damageOutput = damageOutput;
            clone.movement = movement;
            clone.DirectionPos = DirectionPos;
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
}




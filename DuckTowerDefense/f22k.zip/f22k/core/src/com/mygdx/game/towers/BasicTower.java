package com.mygdx.game.towers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class BasicTower extends Tower{
	public BasicTower() {
		super.size = 1;		//size in tile by tile, i.e. 1x1 tile size
		super.cost = 100;
		super.attack = 1;	//attack damage
		super.aSpeed = 1;	//attackSpeed in attacks per second.
		super.range = 4;	//range in tiles.
		super.texture = new Texture(Gdx.files.internal("TowerPlaceHolder.png"));
	}
	
	@Override
	public int getAttack() {
		return this.attack;
	}
	
	@Override
	public Texture getTexture() {
		return this.texture;
	}
	
	@Override
	public int getCost() {
		return this.cost;
	}
	
	
	
}

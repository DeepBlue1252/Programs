package com.mygdx.game.towers;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;

/**
 * This is the actor class used to place a BasicTower onto a stage, for it to be 
 * displayed on the screen. 
 * @author William Robichaux
 *
 */
public class BasicTowerActor extends Actor{
	  private Texture texture;
	  private int locationX;
	  private int locationY;
	  
	  /**
	   * Takes the x and y cords to place the actor and a texture to find what to draw
	   * 
	   * @param tex		Texture - to draw on the screen
	   * @param locX 	int - x cord of where to draw onto the screen
	   * @param locY	int - y cord of where to draw on the screen
	   */
	  public BasicTowerActor(Texture tex,int locX, int locY) {
		  this.texture = tex;
		  locationX = locX;
		  locationY = locY;
	  }
	  
      @Override
      public void draw(Batch batch, float alpha){
          batch.draw(texture,locationX,locationY);
      }
  

}

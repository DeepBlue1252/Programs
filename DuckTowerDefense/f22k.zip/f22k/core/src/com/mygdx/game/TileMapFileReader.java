package com.mygdx.game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class TileMapFileReader {
    /**
     *
     * @param filename name of the text file containing the level's information.
     * @return An ArrayList of characters separated from the text file.
     * @throws Exception if there is no correct file name.
     */
    public static ArrayList<String> readFile(String filename) throws Exception {

        ArrayList<String> textMap = new ArrayList<String>();

        File levelTextFile = new File(filename);
        BufferedReader br = new BufferedReader(new FileReader(filename));

        String st;

        while ((st = br.readLine()) != null) {
            textMap.add(st);
        }
        return textMap;
    }


}

package com.mygdx.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;

public abstract class GameScreen implements Screen {
	public Game game; //I think this class can be private
	
	public GameScreen(Game game) {
		this.game = game;
	}
	
}

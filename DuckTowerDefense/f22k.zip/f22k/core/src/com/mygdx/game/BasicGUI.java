package com.mygdx.game;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import java.util.ArrayList;

public class BasicGUI {
    private ArrayList<Actor> myActors;
    public Stage myStage;
    public Game myGame;

    public BasicGUI(Stage stage, Game game){
        myActors = new ArrayList<Actor>();
        myStage = stage;
        myGame = game;

        addButtons();

        for(int i = 0; i < myActors.size(); i++) {
            myStage.addActor(myActors.get(i));
        }

    }

    public void addButtons() {
        //Add Buttons to myStage here.
    }

    public void draw(){
        myStage.draw();
    }

}

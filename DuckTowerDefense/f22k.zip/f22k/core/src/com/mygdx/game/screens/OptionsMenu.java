package com.mygdx.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.EscapeButton;
import com.mygdx.game.options.Volume;
import com.mygdx.game.returnButton;
import com.mygdx.game.screens.VolumeUp;
public class OptionsMenu implements Screen {
    private Stage stage;
    private Game game;
    public EscapeButton escapebutton;
    public returnButton returnbutton;
    public OptionsMenu(Game game){
        this.game = game;
    }
    public void resize(int width,int height) {

    }

    public void resume(){

    }

    public void dispose() {;
    }

    public void hide() {

    }

    public void render(float delta) {

        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act();
        stage.draw();


    }

    public void show() {

        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        escapebutton = new EscapeButton(stage, game);
        returnbutton = new returnButton(stage,game);
        VolumeUp VolumeUp = new VolumeUp(stage, game);
        VolumeDown VolumeDown = new VolumeDown(stage, game);
    }

    public void pause(){

    }
}
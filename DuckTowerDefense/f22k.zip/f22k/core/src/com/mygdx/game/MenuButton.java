package com.mygdx.game;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;


public class MenuButton extends EasyButton{

    MenuButton(Stage stage, Game game){
        super("How to Play", 128,850, stage, game);
        button.removeListener(button.getClickListener());

        button.addListener(new ScreenSwitchInputListener(game){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.

            }
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is pressed
                game.setScreen(new RealMenu(game));
                return true;
            }
        });
    }
}


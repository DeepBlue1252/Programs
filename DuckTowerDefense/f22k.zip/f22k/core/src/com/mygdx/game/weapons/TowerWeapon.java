package com.mygdx.game.weapons;
import com.mygdx.game.towers.*;

//Tower is used as a factory for other [Type]TowerWeapon classes (i.e. BasicTowerWeapon)
public abstract class TowerWeapon {
	protected Tower equipedTower;
	abstract void Damage(DuckStub duck);	//assign damage to a duck object and kills the duck if it's health <= 0
	
	
}

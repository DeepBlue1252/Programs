package com.mygdx.game;

public class Pos {
    int x;
    int y;

    public Pos(int newX, int newY){
        this.x = newX;
        this.y = newY;
    }

    public int getX(){return this.x;}
    public int getY(){return this.y;}
}

package com.mygdx.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.mygdx.game.OptionsButton;
import jdk.jfr.internal.tool.Main;


/**
 * This class is what is used to create the main menu of the game
 * The textures sprites batch and font are all declared at the start of this class before it
 * is used in the methods.
 */

public class MainMenuScreen extends GameScreen {
	private Texture duck_img,tower_img,arrow_img,quack_img,gameName_img;
	private Sprite duck,tower,arrow,quack,gameName;
	SpriteBatch batch;
	BitmapFont font;
	private Stage stage;

	private MainMenuStartButton startButton;
	private Howtobutton howtoButton;

	private MainMenuOptionsButton optionsButton;



	/**
	 * This works as a create method where it create all the textures
	 * it turns them into sprites, and it makes the batch that draws the sprites and the font that sets text's font
	 *game is initialized here for the screen
	 * @param game
	 */
	public MainMenuScreen(Game game){
		super(game);
		batch = new SpriteBatch();
		font = new BitmapFont();


		duck_img = new Texture("newMenuDuck.jpg");
		duck = new Sprite(duck_img);

		tower_img = new Texture("MenuTower.jpg");
		tower = new Sprite(tower_img);

		arrow_img = new Texture("Arrow.jpg");
		arrow = new Sprite(arrow_img);

		quack_img = new Texture("DuckQuack.jpg");
		quack = new Sprite(quack_img);

		gameName_img = new Texture("Gamename.jpg");
		gameName = new Sprite(gameName_img);





	}

	public void resize(int width,int height) {

	}

	public void resume() {

	}

	/**
	 * This disposes the stage so that it will not remain when exited
	 */
	public void dispose() {
		stage.dispose();
	}

	public void hide() {

	}

	/**
	 * Renders all of the textures onto the screen as well as the stage
	 * it creates the stage as well as initializes the batch with is what causes every texture and text to be
	 * written on the screen
	 * @param delta The time in seconds since the last render.
	 */
	public void render(float delta) {

		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		stage.act();
		stage.draw();

		batch.begin();

		gameName.draw(batch);
		gameName.setPosition(300,700);

		duck.draw(batch);
		duck.setPosition(850,400);

		tower.draw(batch);
		tower.setPosition(100,400);

		arrow.draw(batch);
		arrow.setPosition(470,450);

		quack.draw(batch);
		quack.setPosition(1040,645);

		batch.end();


	}

	/**
	 * The background color is set in this method
	 * there is a viewport that is created to show the screen itself
	 * The button classes are then called to create the buttons themselves
	 *All the button logic is done within the class itself and easybutton class
	 */
	public void show() {
		Gdx.gl.glClearColor(255f, 255f, 0f, 0);
		stage = new Stage(new ScreenViewport());
		Gdx.input.setInputProcessor(stage);

		startButton = new MainMenuStartButton(stage, game);
		howtoButton = new Howtobutton(stage,game);
		optionsButton = new MainMenuOptionsButton(stage, game);

	}

	public void pause() {

	}



}




package com.mygdx.game.towers;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;


/**
 * The Basic Tower Button is used for interactions when the button is clicked
 * it will set the listener of mouse click when pressed and then remove said mouse
 * click listener after a left mouse click. 
 * @author William Robichaux
 *
 */
public class BasicTowerButton{
    private Skin buttonSkin;
    private Game game;
    private String text;
    private TextButton button;
    private Stage stage;
    private TowerTileReader tileReader;
    
    
    /**
     * This is the input listener that changes the left mouse click to be able to place a tower
     */
    private InputListener addTowerListener = new InputListener (){
    	   @Override
    	   public void touchUp(InputEvent event, float x, float y, int pointer, int button)  {
     		  
      	   }
    	   public boolean touchDown(InputEvent event, float x, float y, int pointer, int button)  {
   
    		  BasicTower tower = new BasicTower();
    		  //int inputx = (int)x;
    		  //int inputy = (int)y;
    		  
    		  int inputx = tileReader.calculateTowerCordX(x);
    		  int inputy = tileReader.calculateTowerCordY(y);
    		  
    		  
      	      BasicTowerActor actor = new BasicTowerActor(tower.getTexture(), inputx, inputy);
      	      
      	      stage.addActor(actor);
      	      stage.removeListener(addTowerListener);
      	      
      	      
    	      return true;
    	   }

    	};

    /**
     * 
     * @param buttonText 	the display text on the button
     * @param x_pos 		x cord of the button
     * @param y_pos			y cord of the button
     * @param stage			stage the button is on
     * @param game			libGDX game
     */
    public BasicTowerButton(String buttonText, int x_pos, int y_pos, final Stage stage, Game game){
        buttonSkin = new Skin(Gdx.files.internal("skin/clean-crispy-ui.json"));
        text = buttonText;
        button = new TextButton(buttonText, buttonSkin);
        this.game = game;
        this.stage = stage;
        this.tileReader = new TowerTileReader();

        button.setPosition(x_pos,y_pos);
        button.setSize(128,128);
        stage.addActor(button);
        
        
        this.button.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.
            	//when the button is clicked the user can now place a tower by clicking on the screen
            	setClick(stage);
            	
            }
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
            	
                return true;
            }

        });
    }
    
    private void setClick(final Stage stage) {
    	stage.addListener(this.addTowerListener);
    
    }
   
}
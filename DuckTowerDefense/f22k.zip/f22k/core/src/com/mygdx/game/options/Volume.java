package com.mygdx.game.options;

public class Volume {

    public double masterVolume;


    public Volume(int raw_volume){     //When the user inputs a specific volume level
        double temp_volume = raw_volume;

        masterVolume = raw_volume /= 100;      //Takes the "human" integer volume and turns it into a double that libgdx can work with
    }
    public Volume(double current_vol, double volume_change){ //When the user uses incremental volume buttons
        double temp_volume;
        masterVolume = current_vol + volume_change;  //Takes current volume and adds the change to its current value
    }

    public void turnUp(){
        masterVolume += .01;
    }

    public void turnDown(){
        masterVolume -= 0.01;
    }
}
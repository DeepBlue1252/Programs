package com.mygdx.game.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.mygdx.game.EasyButton;
import com.mygdx.game.RealMenu;
import com.mygdx.game.ScreenSwitchInputListener;

public class Howtobutton extends EasyButton {


    Howtobutton(Stage stage, Game game){
        super("How To Play", 500,250, stage, game);
        button.removeListener(button.getClickListener());
        button.setSize(200,100);
        button.addListener(new ScreenSwitchInputListener(game){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.

            }
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is pressed
                game.setScreen(new RealMenu(game));

                return true;
            }
        });


    }
}












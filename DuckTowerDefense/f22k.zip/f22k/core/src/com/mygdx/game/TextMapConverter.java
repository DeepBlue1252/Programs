package com.mygdx.game;

import java.util.ArrayList;

public class TextMapConverter {
    static Pos startPos;
    static Pos endPos;




    /**
     * @param fileName name of the text file containing the level's information.
     * @return an ArrayList of tiles.
     * @throws Exception if there is no such file name.
     */
    public static ArrayList<Tile> convertToTiles(String fileName) throws Exception {
        ArrayList<String> textMap = new ArrayList<String>();
        textMap = TileMapFileReader.readFile(fileName);

        ArrayList<Tile> tileMap = new ArrayList<Tile>();


        for(int i = 0; i < textMap.size(); i++)
        {
            for(int j = 0; j < textMap.get(i).length(); j++)
            {
                char currentTile = textMap.get(i).charAt(j);

                int sides = 0;
                switch(currentTile)
                {

                    //The getSides function returns a unique value depending on the 4 tiles surrounding it.
                    case '#':
                        sides = getSides(currentTile, i, j, textMap);
                        tileMap.add(new Tile("grass.png", 64*j,960-64*(i+1)));
                        break;

                    case '$':
                        sides = getSides(currentTile, i, j, textMap);
                        String textureName = "water1.png";
                        tileMap.add(new Tile(textureName, 64*j,960-64*(i+1)));
                        break;

                    case 'X':
                        tileMap.add(new Tile("startTile.png", 64*j,960-64*(i+1)));
                        startPos = new Pos(64*j, 960-64*(i+1));
                        break;

                    case 'Z':
                        tileMap.add(new Tile("endTile.png", 64*j,960-64*(i+1)));
                        endPos = new Pos(64*j, 960-64*(i+1));
                        break;
                    default:
                        System.out.println("ERROR: INVALID CHARACTER IN textMap");
                }
            }
        }

        return tileMap;
    }

    private static int getSides(char currentTile, int row, int col, ArrayList<String> textMap){


        //+1 neighbor above sharing texture, +2 for left neighbor, +4 for bottom neighbor, +8 for right neighbor.
        int count = 0;

        //Checking Up for same texture
        if(row != 0)
        {
            if(textMap.get(row-1).charAt(col) == currentTile)
            {
                count += 1;
            }
        }
        //Checking Left
        if(col != 0)
        {
            if(textMap.get(row).charAt(col-1) == currentTile)
            {
                count += 2;
            }
        }
        //Checking Down
        if(row != 14)
        {
            if(textMap.get(row+1).charAt(col) == currentTile)
            {
                count += 4;
            }
        }

        //Checking Right
        if(col != 19)
        {
            if(textMap.get(row).charAt(col+1) == currentTile)
            {
                count += 8;
            }
        }
        return count;
    }
}

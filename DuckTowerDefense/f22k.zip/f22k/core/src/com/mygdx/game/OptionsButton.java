package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.mygdx.game.screens.OptionsMenu;

public class OptionsButton extends EasyButton {
    public OptionsButton(Stage stage, Game game){

        super("Options", 251,850, stage, game);
        button.removeListener(button.getClickListener());
        button.addListener(new ScreenSwitchInputListener(game){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is unreleased.

            }
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                //Logic when button is pressed
                game.setScreen(new OptionsMenu(game));

                return true;
            }
        });


    }
}
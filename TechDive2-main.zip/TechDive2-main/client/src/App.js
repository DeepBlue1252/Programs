// import { useState } from 'react';
// import { createBrowserRouter, RouterProvider } from 'react-router';
// import React from 'react';
// import ReactDOM from 'react-dom';
// import ExamPage from './Pages/ExamPage'; // Import your ExamPage component
// import AdminPage from './Pages/Adminpage';
// import Soim from './Pages/som'; // Import your AdminPage component

// const router = createBrowserRouter([
//   {
//     path: "/",
//     element: <Soim/>,
//   },
// ]);

// ReactDOM.createRoot(document.getElementById("root")).render(
//   <RouterProvider router={router} />
// );